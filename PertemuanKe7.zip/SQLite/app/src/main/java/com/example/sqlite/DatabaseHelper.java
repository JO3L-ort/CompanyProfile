package com.example.sqlite;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DatabaseHelper extends SQLiteOpenHelper {

      //Membuat Variable Konstanta agar saat membuat akses query lebih mudah
      //dan meminimalisir kesalahan pengetikan
      private static final int DATABASE_VERSION=1;

      private static final String DATABASE_NAME = "MHS.db";
      private static final String TABLE_NAME = "Mahasiswa";
      private static final String COLUMN_NAMA = "nama";
      private static final String COLUMN_NIM = "NIM";
      private static final String COLUMN_UMUR ="umur";
      private static final String COLUMN_PATH="path";
      private static final String COLUMN_TEST1="test1";
      private static final String TABLE_CREATE="CREATE TABLE IF NOT EXISTS " +TABLE_NAME
           +"("
           +COLUMN_NIM+"TEXT PRIMARY KEY,"
           +COLUMN_NAMA+"TEXT,"
           +COLUMN_UMUR+"INTEGER, "
           +COLUMN_PATH+"TEXT, "
           +")";


    public DatabaseHelper(Context context) {
        super(context, DatabaseHelper.DATABASE_NAME, null, DATABASE_VERSION);
    }

   
    }
}



