package com.example.pertemuanke7;

import android.content.DialogInterface;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    ImageView imv1,imv2;
    Button btLoad;
    TextView tvAndroURIPath, tvRealPath;

    //variable utk penanda permission
    private final int REQUEST_PERMISSION_READIMAGE=1001;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }

    private void requestPermission(String permissionName, int permissionRequestCode){
        //Nampilin Message untuk alloow permission
        ActivityCompat.requestPermissions(this,
                new String[]{permissionName},permissionRequestCode);
    }

    private void showExplanation(String title, String Message, final String permission, final int permissionRequestCode){
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle(title)
                .setMessage(Message)
                .setPositiveButton(android.R.string.ok, new DialogInterface.OnClickListener(){
                    public void onClick(DialogInterface dialog,int id){
                        //command jika tombol ok
                        requestPermission(permission,permissionRequestCode);
                    }
                });
        //proses utk create rancangan builder kemudian show messagebox
        builder.create().show();
    }
}